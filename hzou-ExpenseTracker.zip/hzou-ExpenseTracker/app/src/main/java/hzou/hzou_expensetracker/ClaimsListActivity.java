package hzou.hzou_expensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

/*
Entry point to application, purpose is to display Claims in brief, and allow the adding
of new claims to ArrayList<Claim> claims. Uses ClaimsListAdapter to populate the listview of
claims.
 */
public class ClaimsListActivity extends ExpenseTrackerActivity {
    private ListView listView_claims;
    public final static String CHOSEN_CLAIM = "Patriots";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claims_list);
    }

    protected void onResume(){
        super.onResume();
        claims = loadFromFile();
        refreshAdapter();
    }

    public void newClaim(View v){
        claims.add(new Claim());
        Toast toast = Toast.makeText(getApplicationContext(),
                "New claim added, click on it to edit", Toast.LENGTH_LONG);
        toast.show();
        saveInFile();
        refreshAdapter();
    }

    private void refreshAdapter(){
        ClaimsListAdapter adapter = new ClaimsListAdapter(this, claims);
        listView_claims = (ListView)findViewById(R.id.listView_claims);
        listView_claims.setAdapter(adapter);
        listView_claims.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), ClaimActivity.class);
                Integer positionInteger = new Integer(position);
                String positionString = positionInteger.toString();
                intent.putExtra(CHOSEN_CLAIM, positionString);
                startActivity(intent);
            }
        });
    }
}
