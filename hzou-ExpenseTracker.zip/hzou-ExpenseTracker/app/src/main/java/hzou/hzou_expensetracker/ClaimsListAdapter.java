package hzou.hzou_expensetracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.ArrayList;

/*
Adapter for populating custom listview
 */
// http://ocddevelopers.com/2014/extend-baseadapter-instead-of-arrayadapter-for-custom-list-items/ January 31, 2015
public class ClaimsListAdapter extends BaseAdapter {
    private ArrayList<Claim> claims;
    private LayoutInflater inflater;

    public ClaimsListAdapter(Context context, ArrayList<Claim> claims){
        this.claims = claims;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return claims.size();
    }

    @Override
    public Object getItem(int position) {
        return claims.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view;
        ViewHolder holder;
        // if (convertView == null){
        if (true){
            view = inflater.inflate(R.layout.claims_list, parent, false);
            holder = new ViewHolder();
            holder.description =
                    (TextView) view.findViewById(R.id.text_claimsList_description);
            holder.startDate = (TextView) view.findViewById(R.id.text_claimsList_startDate);
            holder.endDate = (TextView) view.findViewById(R.id.text_claimsList_endDate);
        }
        else {
            view = convertView;
            holder = (ViewHolder)view.getTag();
        }

        Claim claim = claims.get(position);
        holder.description.setText(claim.getDescription());
        holder.startDate.setText
                (DateFormat.getDateInstance(DateFormat.LONG).
                        format(claim.getStartDate().getTime()));
        holder.endDate.setText
                (DateFormat.getDateInstance(DateFormat.LONG).format(claim.getEndDate().getTime()));

        return view;
    }

    private class ViewHolder{
        public TextView description, startDate, endDate;
    }
}
