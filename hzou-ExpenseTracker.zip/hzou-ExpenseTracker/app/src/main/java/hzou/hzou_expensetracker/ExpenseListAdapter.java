package hzou.hzou_expensetracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.ArrayList;

/*
Adapter for populating custom listview
 */
// http://ocddevelopers.com/2014/extend-baseadapter-instead-of-arrayadapter-for-custom-list-items/ January 31, 2015
public class ExpenseListAdapter extends BaseAdapter {
    private ArrayList<Expense> expenses;
    private LayoutInflater inflater;

    public ExpenseListAdapter(Context context, ArrayList<Expense> expenses){
        this.expenses = expenses;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return expenses.size();
    }

    @Override
    public Object getItem(int position) {
        return expenses.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view = inflater.inflate(R.layout.expense_list, parent, false);
        ViewHolder holder = new ViewHolder();
        holder.date = (TextView) view.findViewById(R.id.text_expenseList_date);
        holder.description =
                    (TextView) view.findViewById(R.id.text_expenseList_description);
        holder.category = (TextView) view.findViewById(R.id.text_expenseList_category);
        holder.amountCurrency = (TextView) view.findViewById(R.id.text_expenseList_amountCurrency);


        Expense expense = expenses.get(position);
        holder.date.setText
                (DateFormat.getDateInstance(DateFormat.LONG).
                        format(expense.getDate().getTime()));
        holder.category.setText(expense.getCategory());
        holder.description.setText(expense.getDescription());
        holder.amountCurrency.setText(expense.getAmount()+" "+expense.getCurrency());

        return view;
    }

    private class ViewHolder{
        public TextView date, category, description, amountCurrency;
    }
}