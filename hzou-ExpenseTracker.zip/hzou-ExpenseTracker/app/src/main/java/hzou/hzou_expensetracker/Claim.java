package hzou.hzou_expensetracker;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/*
Model for storing the claims' data.
 */
public class Claim extends CurrencyModel{
    private GregorianCalendar startDate;
    private GregorianCalendar endDate;
    private String description;
    private ArrayList<Expense> expenses;
    private int status;
    private int amountCad;
    private int amountUsd;
    private int amountEur;
    private int amountGbp;
    private static final String STATUS_IN_PROGRESS = "In progress";
    private static final String STATUS_SUBMITTED = "Submitted";
    private static final String STATUS_RETURNED = "Returned";
    private static final String STATUS_APPROVED = "Approved";
    public static final String[] STATUS =
            {STATUS_IN_PROGRESS, STATUS_SUBMITTED,STATUS_RETURNED,STATUS_APPROVED};

    private static final String DESCRIPTION_DEFAULT =
            "(Untitled claim)";

    public Claim() {
        startDate = new GregorianCalendar();
        endDate = new GregorianCalendar();
        description = DESCRIPTION_DEFAULT;
        expenses = new ArrayList<Expense>();
        status = 0;
        amountCad = 0;
        amountUsd = 0;
        amountEur = 0;
        amountGbp = 0;
    }

    public Claim(GregorianCalendar startDate, GregorianCalendar endDate, String description,
                 ArrayList<Expense> expenses, int status, int amountCad, int amountUsd,
                 int amountEur, int amountGbp) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;
        this.expenses = expenses;
        this.status = status;
        this.amountCad = amountCad;
        this.amountUsd = amountUsd;
        this.amountEur = amountEur;
        this.amountGbp = amountGbp;
    }

    public GregorianCalendar getStartDate() {
        return startDate;
    }

    public void setStartDate(GregorianCalendar startDate) {
        this.startDate = startDate;
    }

    public GregorianCalendar getEndDate() {
        return endDate;
    }

    public void setEndDate(GregorianCalendar endDate) {
        this.endDate = endDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ArrayList<Expense> getExpenses(){
        return expenses;
    }

    public void addExpense(Expense expense) {
        expenses.add(expense);
        if (expense.getCurrency().equals(CURRENCY_CAD)) {
            amountCad = amountCad + expense.getAmount();
        } else if (expense.getCurrency().equals(CURRENCY_USD)) {
            amountUsd = amountUsd + expense.getAmount();
        } else if (expense.getCurrency().equals(CURRENCY_EUR)) {
            amountEur = amountEur + expense.getAmount();
        } else if (expense.getCurrency().equals(CURRENCY_GBP)) {
            amountGbp = amountGbp + expense.getAmount();
        }
    }

    public void removeExpense(Expense expense) {
        if (expense.getCurrency().equals(CURRENCY_CAD)) {
            amountCad = amountCad - expense.getAmount();
        } else if (expense.getCurrency().equals(CURRENCY_USD)) {
            amountUsd = amountUsd - expense.getAmount();
        } else if (expense.getCurrency().equals(CURRENCY_EUR)) {
            amountEur = amountEur - expense.getAmount();
        } else if (expense.getCurrency().equals(CURRENCY_GBP)) {
            amountGbp = amountGbp - expense.getAmount();
        }
        expenses.remove(expense);
    }

    public void updateAmounts() {
        amountCad = 0;
        amountUsd = 0;
        amountEur = 0;
        amountGbp = 0;
        for (Expense expense : expenses) {
            if (expense.getCurrency().equals(CURRENCY_CAD)) {
                amountCad = amountCad + expense.getAmount();
            } else if (expense.getCurrency().equals(CURRENCY_USD)) {
                amountUsd = amountUsd + expense.getAmount();
            } else if (expense.getCurrency().equals(CURRENCY_EUR)) {
                amountEur = amountEur + expense.getAmount();
            } else if (expense.getCurrency().equals(CURRENCY_GBP)) {
                amountGbp = amountGbp + expense.getAmount();
            }
        }
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getAmountCad() {
        return amountCad;
    }

    public int getAmountUsd() {
        return amountUsd;
    }

    public int getAmountEur() {
        return amountEur;
    }

    public int getAmountGbp() {
        return amountGbp;
    }
}
