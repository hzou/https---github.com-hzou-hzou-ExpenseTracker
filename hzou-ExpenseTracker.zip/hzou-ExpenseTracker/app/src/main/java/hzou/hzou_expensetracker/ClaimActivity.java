package hzou.hzou_expensetracker;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/*
Shows detailed view of one Claim item, including a list of expenses populated by ExpenseListAdapter.
Holds functions for user input  to edit values for the Claim.
 */
public class ClaimActivity extends ExpenseTrackerActivity {
    private ListView listView_expense;
    private int claimPosition;
    public final static String CHOSEN_CLAIM = "Patriots";
    public final static String CHOSEN_EXPENSE = "Seahawks";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claim);
        Intent intent = getIntent();
        claimPosition = Integer.parseInt(intent.getStringExtra(ClaimsListActivity.CHOSEN_CLAIM));
        setAdapter();
        setTextViews();
    }

    @Override
    protected void onResume(){
        super.onResume();
        claims=loadFromFile();
        setAdapter();
    }

    private void setAdapter(){
        ExpenseListAdapter adapter = new ExpenseListAdapter(this, claims.get(claimPosition).getExpenses());
        listView_expense = (ListView)findViewById(R.id.listView_expense);
        listView_expense.setAdapter(adapter);
        listView_expense.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), ExpenseActivity.class);
                Integer positionInteger = new Integer(position);
                String positionString = positionInteger.toString();
                intent.putExtra(CHOSEN_EXPENSE, positionString);
                Integer claimPositionInteger = new Integer(claimPosition);
                String claimPositionString = claimPositionInteger.toString();
                intent.putExtra(CHOSEN_CLAIM, claimPositionString);
                startActivity(intent);
            }
        });
    }

    private void setTextViews(){
        setStatusSpinner();
        TextView description = (TextView)findViewById(R.id.text_claimDescription);
        TextView startDate = (TextView)findViewById(R.id.text_claimStartDate);
        TextView endDate = (TextView)findViewById(R.id.text_claimEndDate);
        description.setText(claims.get(claimPosition).getDescription());
        startDate.setText
                (DateFormat.getDateInstance(DateFormat.LONG).
                        format(claims.get(claimPosition).getStartDate().getTime()));
        endDate.setText
                (DateFormat.getDateInstance(DateFormat.LONG).format(claims.get(claimPosition).getEndDate().getTime()));
    }

    public void newClaim(View v){

    }

    private void setStatusSpinner(){
        Spinner spinner;
        spinner = (Spinner)findViewById(R.id.spinner_status);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>
                        (this, android.R.layout.simple_spinner_item, claims.get(claimPosition).STATUS);
        spinner.setAdapter(adapter);
        spinner.setSelection(claims.get(claimPosition).getStatus());
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                claims.get(claimPosition).setStatus(position);
                saveInFile();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }

        });
    }

    public void deleteClaim(View v){
        claims.remove(claims.get(claimPosition));
        saveInFile();
        finish();
    }

    public void newExpense(View v){
        claims.get(claimPosition).addExpense(new Expense());
        saveInFile();
        claims=loadFromFile();
        setAdapter();
        Toast.makeText(this,"New expense added",Toast.LENGTH_SHORT).show();
    }

    public void editDescription(View v) {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        alert.setTitle("Description");
        alert.setMessage("Destination and reason for travel");

        // Set an EditText view to get user input
        final EditText input = new EditText(this);
        alert.setView(input);

        alert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                claims.get(claimPosition).setDescription(input.getText().toString());
                saveInFile();
                setTextViews();
            }
        });

        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        alert.show();
    }

    public void displayTotals(View v){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        alert.setTitle("Totals: ");
        alert.setMessage("CAD: " + claims.get(claimPosition).getAmountCad() + "\n" + "USD: " + claims.get(claimPosition).getAmountUsd() + "\n" + "EUR: " + claims.get(claimPosition).getAmountEur() + "\n" + "GBP: " + claims.get(claimPosition).getAmountGbp());
        alert.show();
    }

    public void changeStartDate(View v) {
            class StartDatePicker extends DialogFragment
                implements DatePickerDialog.OnDateSetListener {

            @Override
            public Dialog onCreateDialog(Bundle savedInstanceState) {
                // Use the current date as the default date in the picker
                final Calendar c = Calendar.getInstance();
                int year = claims.get(claimPosition).getStartDate().get(Calendar.YEAR);
                int month = claims.get(claimPosition).getStartDate().get(Calendar.MONTH);
                int day = claims.get(claimPosition).getStartDate().get(Calendar.DAY_OF_MONTH);

                // Create a new instance of DatePickerDialog and return it
                return new DatePickerDialog(getActivity(), this, year, month, day);
            }

            public void onDateSet(DatePicker view, int year, int month, int day) {
                claims.get(claimPosition).setStartDate(new GregorianCalendar(year, month, day));
                saveInFile();
                setTextViews();
            }
        }

        DialogFragment newFragment = new StartDatePicker();
        newFragment.show(getFragmentManager(), "datePicker");
    }

    public void changeEndDate(View v) {
        class StartDatePicker extends DialogFragment
                implements DatePickerDialog.OnDateSetListener {

            @Override
            public Dialog onCreateDialog(Bundle savedInstanceState) {
                int year = claims.get(claimPosition).getEndDate().get(Calendar.YEAR);
                int month = claims.get(claimPosition).getEndDate().get(Calendar.MONTH);
                int day = claims.get(claimPosition).getEndDate().get(Calendar.DAY_OF_MONTH);

                // Create a new instance of DatePickerDialog and return it
                return new DatePickerDialog(getActivity(), this, year, month, day);
            }

            public void onDateSet(DatePicker view, int year, int month, int day) {
                claims.get(claimPosition).setEndDate(new GregorianCalendar(year, month, day));
                saveInFile();
                setTextViews();
            }
        }

        DialogFragment newFragment = new StartDatePicker();
        newFragment.show(getFragmentManager(), "datePicker");
    }

    public void emailClaim(View v){

    }
}