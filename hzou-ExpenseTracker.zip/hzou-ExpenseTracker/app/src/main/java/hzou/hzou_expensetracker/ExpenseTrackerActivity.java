package hzou.hzou_expensetracker;

import android.app.Activity;
import android.os.Bundle;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;

/*
Purpose: references the model for the list of claims (all data used for this app) and
stores the Gson methods.
 */
public class ExpenseTrackerActivity extends Activity{

    protected ArrayList<Claim> claims;
    protected static final String FILENAME = "file.sav";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        claims = loadFromFile();
    }

    // Gson method created in lab in class
    protected ArrayList<Claim> loadFromFile(){
        Gson gson = new Gson();
        ArrayList<Claim> claims = new ArrayList<Claim>();
        try {
            FileInputStream fis = openFileInput(FILENAME);
            InputStreamReader isr = new InputStreamReader(fis);
            // https://sites.google.com/site/gson/gson-user-guide 2015-01-21
            Type dataType = new TypeToken<ArrayList<Claim>>() {}.getType();
            claims = gson.fromJson(isr, dataType);
            fis.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();
        }
        if (claims == null){
            claims = new ArrayList<Claim>();
        }
        return claims;
    }

    // Gson method created in lab in class
    protected void saveInFile() {
        Gson gson = new Gson();
        try {
            FileOutputStream fos = openFileOutput(FILENAME,
                    0);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            gson.toJson(claims, osw);
            osw.flush();
            fos.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
