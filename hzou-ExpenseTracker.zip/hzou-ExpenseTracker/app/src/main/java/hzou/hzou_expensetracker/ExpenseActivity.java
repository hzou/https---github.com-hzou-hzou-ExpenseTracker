package hzou.hzou_expensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/*
Unfinished... Similar to ClaimActivity, for editing details for each Expense.
 */
public class ExpenseActivity extends ExpenseTrackerActivity {
    int claimPosition;
    int expensePosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);
        Intent intent = getIntent();
        expensePosition = Integer.parseInt(intent.getStringExtra(ClaimActivity.CHOSEN_EXPENSE));
        claimPosition = Integer.parseInt(intent.getStringExtra(ClaimActivity.CHOSEN_CLAIM));
    }



    public void deleteExpense(View v){
        claims.get(claimPosition).removeExpense(claims.get(claimPosition).getExpenses().get(expensePosition));
        saveInFile();
        finish();
    }

}
