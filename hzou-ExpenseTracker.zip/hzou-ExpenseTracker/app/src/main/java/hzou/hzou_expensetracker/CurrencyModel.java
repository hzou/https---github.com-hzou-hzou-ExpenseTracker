package hzou.hzou_expensetracker;

/*
Since Claim and Expense share the currency values, I put them in a superclass.
 */
public class CurrencyModel {
    protected static final String CURRENCY_CAD = "CAD";
    protected static final String CURRENCY_USD = "USD";
    protected static final String CURRENCY_EUR = "EUR";
    protected static final String CURRENCY_GBP = "GBP";
}