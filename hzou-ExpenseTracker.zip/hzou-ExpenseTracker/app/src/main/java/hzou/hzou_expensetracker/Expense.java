package hzou.hzou_expensetracker;

import java.util.GregorianCalendar;

// Model for storing Expense data
public class Expense extends CurrencyModel {
    private GregorianCalendar date;
    private String category;
    private String description;
    private int amount;
    private String currency;
    private static final String SELECT_ONE = "";
    private static final String CATEGORY_AIRFARE = "Air fare";
    private static final String CATEGORY_GROUND_TRANSPORT = "Ground transport";
    private static final String CATEGORY_VEHICLE_RENTAL = "Vehicle Rental";
    private static final String CATEGORY_FUEL = "Fuel";
    private static final String CATEGORY_PARKING = "Parking";
    private static final String CATEGORY_REGISTRATION = "Registration";
    private static final String CATEGORY_ACCOMMODATION = "Accommodation";
    private static final String CATEGORY_MEAL = "Meal";
    private static final String DESCRIPTION_DEFAULT = "Please enter description";

    public Expense(){
        super();
        date = new GregorianCalendar();
        category = SELECT_ONE;
        description = DESCRIPTION_DEFAULT;
        amount = 0;
        currency = CURRENCY_CAD;
    }

    public Expense(GregorianCalendar date, String category, String description, int amount, String currency) {
        super();
        this.date = date;
        this.category = category;
        this.description = description;
        this.amount = amount;
        this.currency = currency;
    }

    public GregorianCalendar getDate() {
        return date;
    }

    public void setDate(GregorianCalendar date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory_airfare() {
        category = CATEGORY_AIRFARE;
    }
    public void setCategory_groundTransport() {
        category = CATEGORY_GROUND_TRANSPORT;
    }
    public void setCategory_vehicleRental() {
        category = CATEGORY_VEHICLE_RENTAL;
    }
    public void setCategory_fuel(){
        category = CATEGORY_FUEL;
    }
    public void setCategory_parking() {
        category = CATEGORY_PARKING;
    }
    public void setCategory_registration(){
        category = CATEGORY_REGISTRATION;
    }
    public void setCategory_accommodation(){
        category = CATEGORY_ACCOMMODATION;
    }
    public void setCategory_meal(){
        category = CATEGORY_MEAL;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency_cad () {
        currency = CURRENCY_CAD;
    }
    public void setCurrency_usd () {
        currency = CURRENCY_USD;
    }
    public void setCurrency_eur () {
        currency = CURRENCY_EUR;
    }
    public void setCurrency_gbp () {
        currency = CURRENCY_GBP;
    }

}
